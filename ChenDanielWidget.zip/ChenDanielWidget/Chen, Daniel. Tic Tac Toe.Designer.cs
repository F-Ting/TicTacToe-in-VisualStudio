﻿namespace WindowsFormsApplication3
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game));
            this.A1 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.A3 = new System.Windows.Forms.Button();
            this.A2 = new System.Windows.Forms.Button();
            this.C1 = new System.Windows.Forms.Button();
            this.B1 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.C2 = new System.Windows.Forms.Button();
            this.C3 = new System.Windows.Forms.Button();
            this.resetScore = new System.Windows.Forms.Button();
            this.win1 = new System.Windows.Forms.TextBox();
            this.win2 = new System.Windows.Forms.TextBox();
            this.player1Lable = new System.Windows.Forms.Label();
            this.player2Lable = new System.Windows.Forms.Label();
            this.Score = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.newGame = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.about = new System.Windows.Forms.ToolStripMenuItem();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameButton = new System.Windows.Forms.ToolStripMenuItem();
            this.exitButton = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.funModeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.funModeEnabled = new System.Windows.Forms.ToolStripMenuItem();
            this.funModeDisabled = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutButton = new System.Windows.Forms.ToolStripMenuItem();
            this.showTurn = new System.Windows.Forms.TextBox();
            this.funModeText = new System.Windows.Forms.Label();
            this.funModeCountDownText = new System.Windows.Forms.TextBox();
            this.funModeExplainedButton = new System.Windows.Forms.ToolStripMenuItem();
            this.menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // A1
            // 
            this.A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F);
            this.A1.Location = new System.Drawing.Point(34, 99);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(68, 62);
            this.A1.TabIndex = 1;
            this.A1.UseVisualStyleBackColor = true;
            this.A1.Click += new System.EventHandler(this.buttonClick);
            // 
            // B2
            // 
            this.B2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F);
            this.B2.Location = new System.Drawing.Point(108, 167);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(68, 62);
            this.B2.TabIndex = 2;
            this.B2.UseVisualStyleBackColor = true;
            this.B2.Click += new System.EventHandler(this.buttonClick);
            // 
            // A3
            // 
            this.A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F);
            this.A3.Location = new System.Drawing.Point(182, 99);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(68, 62);
            this.A3.TabIndex = 3;
            this.A3.UseVisualStyleBackColor = true;
            this.A3.Click += new System.EventHandler(this.buttonClick);
            // 
            // A2
            // 
            this.A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F);
            this.A2.Location = new System.Drawing.Point(108, 99);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(68, 62);
            this.A2.TabIndex = 4;
            this.A2.UseVisualStyleBackColor = true;
            this.A2.Click += new System.EventHandler(this.buttonClick);
            // 
            // C1
            // 
            this.C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F);
            this.C1.Location = new System.Drawing.Point(34, 235);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(68, 62);
            this.C1.TabIndex = 5;
            this.C1.UseVisualStyleBackColor = true;
            this.C1.Click += new System.EventHandler(this.buttonClick);
            // 
            // B1
            // 
            this.B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F);
            this.B1.Location = new System.Drawing.Point(34, 167);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(68, 62);
            this.B1.TabIndex = 6;
            this.B1.UseVisualStyleBackColor = true;
            this.B1.Click += new System.EventHandler(this.buttonClick);
            // 
            // B3
            // 
            this.B3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F);
            this.B3.Location = new System.Drawing.Point(182, 164);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(68, 62);
            this.B3.TabIndex = 7;
            this.B3.UseVisualStyleBackColor = true;
            this.B3.Click += new System.EventHandler(this.buttonClick);
            // 
            // C2
            // 
            this.C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F);
            this.C2.Location = new System.Drawing.Point(108, 235);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(68, 62);
            this.C2.TabIndex = 8;
            this.C2.UseVisualStyleBackColor = true;
            this.C2.Click += new System.EventHandler(this.buttonClick);
            // 
            // C3
            // 
            this.C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F);
            this.C3.Location = new System.Drawing.Point(182, 232);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(68, 62);
            this.C3.TabIndex = 9;
            this.C3.UseVisualStyleBackColor = true;
            this.C3.Click += new System.EventHandler(this.buttonClick);
            // 
            // resetScore
            // 
            this.resetScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.resetScore.Location = new System.Drawing.Point(364, 187);
            this.resetScore.Name = "resetScore";
            this.resetScore.Size = new System.Drawing.Size(97, 37);
            this.resetScore.TabIndex = 10;
            this.resetScore.Text = "Reset Score";
            this.resetScore.UseVisualStyleBackColor = true;
            this.resetScore.Click += new System.EventHandler(this.resetScore_Click);
            // 
            // win1
            // 
            this.win1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.win1.Location = new System.Drawing.Point(311, 99);
            this.win1.Name = "win1";
            this.win1.ReadOnly = true;
            this.win1.Size = new System.Drawing.Size(87, 32);
            this.win1.TabIndex = 11;
            this.win1.Text = "0";
            // 
            // win2
            // 
            this.win2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.win2.Location = new System.Drawing.Point(433, 99);
            this.win2.Name = "win2";
            this.win2.ReadOnly = true;
            this.win2.Size = new System.Drawing.Size(93, 32);
            this.win2.TabIndex = 12;
            this.win2.Text = "0";
            // 
            // player1Lable
            // 
            this.player1Lable.AutoSize = true;
            this.player1Lable.BackColor = System.Drawing.Color.Transparent;
            this.player1Lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.player1Lable.Location = new System.Drawing.Point(306, 144);
            this.player1Lable.Name = "player1Lable";
            this.player1Lable.Size = new System.Drawing.Size(92, 26);
            this.player1Lable.TabIndex = 13;
            this.player1Lable.Text = "Player 1";
            // 
            // player2Lable
            // 
            this.player2Lable.AutoSize = true;
            this.player2Lable.BackColor = System.Drawing.Color.Transparent;
            this.player2Lable.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.player2Lable.Location = new System.Drawing.Point(434, 144);
            this.player2Lable.Name = "player2Lable";
            this.player2Lable.Size = new System.Drawing.Size(92, 26);
            this.player2Lable.TabIndex = 14;
            this.player2Lable.Text = "Player 2";
            // 
            // Score
            // 
            this.Score.AutoSize = true;
            this.Score.BackColor = System.Drawing.Color.Transparent;
            this.Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.Score.Location = new System.Drawing.Point(376, 44);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(85, 31);
            this.Score.TabIndex = 15;
            this.Score.Text = "Score";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.label1.Location = new System.Drawing.Point(65, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 31);
            this.label1.TabIndex = 16;
            this.label1.Text = "Tic Tac Toe";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGame});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // newGame
            // 
            this.newGame.Name = "newGame";
            this.newGame.Size = new System.Drawing.Size(132, 22);
            this.newGame.Text = "New Game";
            this.newGame.Click += new System.EventHandler(this.newGame_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(61, 20);
            this.toolStripMenuItem2.Text = "Options";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.about});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(44, 20);
            this.toolStripMenuItem4.Text = "Help";
            // 
            // about
            // 
            this.about.Name = "about";
            this.about.Size = new System.Drawing.Size(107, 22);
            this.about.Text = "About";
            this.about.Click += new System.EventHandler(this.about_Click);
            // 
            // menu
            // 
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.optionsMenu,
            this.toolStripMenuItem6});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(550, 24);
            this.menu.TabIndex = 18;
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameButton,
            this.exitButton});
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(37, 20);
            this.fileMenu.Text = "File";
            // 
            // newGameButton
            // 
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(132, 22);
            this.newGameButton.Text = "New Game";
            this.newGameButton.Click += new System.EventHandler(this.newGame_Click);
            // 
            // exitButton
            // 
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(132, 22);
            this.exitButton.Text = "Exit";
            this.exitButton.Click += new System.EventHandler(this.exitGame);
            // 
            // optionsMenu
            // 
            this.optionsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.funModeMenu});
            this.optionsMenu.Name = "optionsMenu";
            this.optionsMenu.Size = new System.Drawing.Size(61, 20);
            this.optionsMenu.Text = "Options";
            // 
            // funModeMenu
            // 
            this.funModeMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.funModeEnabled,
            this.funModeDisabled});
            this.funModeMenu.Name = "funModeMenu";
            this.funModeMenu.Size = new System.Drawing.Size(152, 22);
            this.funModeMenu.Text = "Fun Mode";
            // 
            // funModeEnabled
            // 
            this.funModeEnabled.Name = "funModeEnabled";
            this.funModeEnabled.Size = new System.Drawing.Size(119, 22);
            this.funModeEnabled.Text = "Enabled";
            this.funModeEnabled.Click += new System.EventHandler(this.enableFunMode);
            // 
            // funModeDisabled
            // 
            this.funModeDisabled.Name = "funModeDisabled";
            this.funModeDisabled.Size = new System.Drawing.Size(119, 22);
            this.funModeDisabled.Text = "Disabled";
            this.funModeDisabled.Click += new System.EventHandler(this.disableFunMode);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.funModeExplainedButton,
            this.aboutButton});
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(44, 20);
            this.toolStripMenuItem6.Text = "Help";
            // 
            // aboutButton
            // 
            this.aboutButton.Name = "aboutButton";
            this.aboutButton.Size = new System.Drawing.Size(181, 22);
            this.aboutButton.Text = "About";
            this.aboutButton.Click += new System.EventHandler(this.about_Click);
            // 
            // showTurn
            // 
            this.showTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.showTurn.Location = new System.Drawing.Point(86, 303);
            this.showTurn.Name = "showTurn";
            this.showTurn.Size = new System.Drawing.Size(113, 38);
            this.showTurn.TabIndex = 17;
            this.showTurn.Text = "X\'s Turn";
            // 
            // funModeText
            // 
            this.funModeText.AutoSize = true;
            this.funModeText.BackColor = System.Drawing.Color.DarkRed;
            this.funModeText.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.funModeText.ForeColor = System.Drawing.Color.Fuchsia;
            this.funModeText.Location = new System.Drawing.Point(305, 259);
            this.funModeText.Name = "funModeText";
            this.funModeText.Size = new System.Drawing.Size(135, 31);
            this.funModeText.TabIndex = 28;
            this.funModeText.Text = "Fun Mode";
            // 
            // funModeCountDownText
            // 
            this.funModeCountDownText.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.funModeCountDownText.Location = new System.Drawing.Point(462, 255);
            this.funModeCountDownText.Name = "funModeCountDownText";
            this.funModeCountDownText.Size = new System.Drawing.Size(45, 35);
            this.funModeCountDownText.TabIndex = 29;
            this.funModeCountDownText.Text = "0";
            // 
            // funModeExplainedButton
            // 
            this.funModeExplainedButton.Name = "funModeExplainedButton";
            this.funModeExplainedButton.Size = new System.Drawing.Size(181, 22);
            this.funModeExplainedButton.Text = "Fun Mode Explained";
            this.funModeExplainedButton.Click += new System.EventHandler(this.funModeExplainedButton_Click);
            // 
            // Game
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(550, 344);
            this.Controls.Add(this.funModeCountDownText);
            this.Controls.Add(this.funModeText);
            this.Controls.Add(this.showTurn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.player2Lable);
            this.Controls.Add(this.player1Lable);
            this.Controls.Add(this.win2);
            this.Controls.Add(this.win1);
            this.Controls.Add(this.resetScore);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.A1);
            this.Controls.Add(this.menu);
            this.MainMenuStrip = this.menu;
            this.Name = "Game";
            this.Text = "Tic Tac Toe";
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.Button A1;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button A3;
        private System.Windows.Forms.Button A2;
        private System.Windows.Forms.Button C1;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button C2;
        private System.Windows.Forms.Button C3;
        private System.Windows.Forms.Button resetScore;
        private System.Windows.Forms.TextBox win1;
        private System.Windows.Forms.TextBox win2;
        private System.Windows.Forms.Label player1Lable;
        private System.Windows.Forms.Label player2Lable;
        private System.Windows.Forms.Label Score;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem newGame;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem about;
        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.TextBox showTurn;
        // private System.Windows.Forms.ToolStripMenuItem exit;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem newGameButton;
        private System.Windows.Forms.ToolStripMenuItem exit;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem exitButton;
        private System.Windows.Forms.ToolStripMenuItem aboutButton;
        private System.Windows.Forms.ToolStripMenuItem optionsMenu;
        private System.Windows.Forms.ToolStripMenuItem funModeMenu;
        private System.Windows.Forms.ToolStripMenuItem funModeEnabled;
        private System.Windows.Forms.ToolStripMenuItem funModeDisabled;
        private System.Windows.Forms.Label funModeText;
        private System.Windows.Forms.TextBox funModeCountDownText;
        private System.Windows.Forms.ToolStripMenuItem funModeExplainedButton;
    }
}

