﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3

/*
 * This program is the traditional Tic Tac Toe game.
 * It's a two player board game where both player tries to connect their game piece (either  X or O) 
 * Here's some general features
 * -A 2 player Tic Tac Toe game board
 * -Score keeping system that players can keep track of their wins
 * -Fun Mode (Descriptions are under the 'help' menu strip in game) 
 * 
 * Special Feature: Fun Mode
 * Fun mode fixes the traditional issue of normal Tic Tac Toe games in which it would always end up in a draw.
 * Changes the game dynamic that makes players think more before they put down their next move
 * 
 *
 * Things learned from this assignment:
 * Very similar coding style compared to java.
 * Being able to create buttons instantly rather than programming it to do so is very efficent and useful.
 * Naming was EXTREAMELY IMPORTANT.
 * The amount of error that showed up due to incorrect naming was just disastrous for me through out this assignment.
 * Finnaly after the third time of recreating the program was I able to find out it was the naming conflict between an object and method.
 * 
 * 
 * 
 * 
 * 
 * */
{
    public partial class Game : Form
    {
        private bool funModeActive = false;
        private bool turn = false; // Determin who's turn it is
                           // false is X's turn
                           // true is O's turn
        private int player1Score = 0;  // Score for Player 1
        private int player2Score = 0;  // Score for Player 2
        private int turnCount = 0;
        private int funModeCountDown = 0;
        public Game()
        {

            
            InitializeComponent();
            funModeText.Visible = false;           //  Make "Fun Mode" text not visible
            funModeCountDownText.Visible = false;      //
        }

        private void buttonClick(object sender, EventArgs e)
        {
            Button b = (Button)sender;  // Make buttonClick Method work for all buttons
            if (funModeActive == true)
                haveFun();
            b.Enabled = false;          // Disable the button when pressed
            if (turn)                   // if player O's turn
            {
                b.Text = "O";           // Put "O" on the button pressed
                turnCount++;            // Increase turn count by 1
                showTurn.Text = "X's Turn"; // Show that now it's O's turn
                turn = false;           // Change to X's turn
            }
            else
            {
                b.Text = "X";           // Put "X" on the button pressed
                turnCount++;
                showTurn.Text = "O's Turn"; // Show that now it's X's turn
                turn = true;            // Change to O' turn
            }
            
            checkForWinner();
        }


        private void newGame_Click(object sender, EventArgs e)
        {
            foreach (Control b in Controls)             // For every control in the game, give it a variable b
            {
                if (b is Button && b != resetScore)     // if b is a button except for the button resetScore
                {
                    b.Enabled = true;                   // enable the buttons again
                    b.Text = "";                        // reset the text to blank
                    turnCount = 0;                      // reset turnCount
                    funModeActive = false;              // disable funMode
                    funModeText.Visible = false;                 //  Make "Fun Mode" text not visible
                    funModeCountDownText.Visible = false;            //  Make funModeCountDown textbox not visible
            }
        }
            
                
        }

        //checking for winner
        private void checkForWinner()
        {
            bool thereIsAWinner = false;
                //Horizontal check
                if (A1.Text == A2.Text && A2.Text == A3.Text && A1.Text != "")
                    thereIsAWinner = true;
                else if (B1.Text == B2.Text && B2.Text == B3.Text && B1.Text != "")
                    thereIsAWinner = true;
                else if (C1.Text == C2.Text && C2.Text == C3.Text && C1.Text != "")
                    thereIsAWinner = true;

                //Vertical check
                if (A1.Text == B1.Text && B1.Text == C1.Text && A1.Text != "")
                    thereIsAWinner = true;
                else if (A2.Text == B2.Text && B2.Text == C2.Text && A2.Text != "")
                    thereIsAWinner = true;
                else if (A3.Text == B3.Text && B3.Text == C3.Text && A3.Text != "")
                    thereIsAWinner = true;
                
                // Diagonal Check
                if (A1.Text == B2.Text && B2.Text == C3.Text && A1.Text != "")
                    thereIsAWinner = true;
                else if (A3.Text == B2.Text && B2.Text == C1.Text && A3.Text != "")
                    thereIsAWinner = true;

                

            if(thereIsAWinner)
            {
                disableButton(); //disable buttons (Method is below);

                //Set a String for winner
                String winner = "";

                // if X wins
                if (turn)
                {
                    winner = "X";                           
                    player1Score++;                         // increase player1Score by 1
                    win1.Text = player1Score.ToString();    // display player1Score in "win1" textbox
                }
                // if O wins
                else
                {
                    winner = "O";
                    player2Score++;                        // increase player2Score by 1
                    win2.Text = player2Score.ToString();   // display player2Score in "win2" textbox
                }

                MessageBox.Show(winner + " Wins!");        // Pop-up window showing the winner

            }
            // if no one wins 
            else if (turnCount == 9) 
            {
                MessageBox.Show("Draw!");
                turnCount = 0;                              // reset turnCount to 0
            }
               

        }

        // About game
        private void about_Click(object sender, EventArgs e)
        { 
            MessageBox.Show("By Daniel", "About Game");
        }

        // reset score
        private void resetScore_Click(object sender, EventArgs e)
        {
           player1Score = 0;
           player2Score = 0;
           win1.Text = player1Score.ToString();             // display player1Score in "win1" textbox
           win2.Text = player2Score.ToString();             // display player2Score in "win2" textbox
        }

        // disable buttons when clicked
        private void disableButton()
        {
            foreach (Control b in Controls)  // for every controls(buttons, textbox, menu strip.. ect) in the game
                                             // give the variable b when running this method
            {
                if (b is Button && b != resetScore) // if b is a button except the resetscore button
                    b.Enabled = false;              // disable the button when clicked
            }
        }

        private void exitGame(object sender, EventArgs e)
        {
            Application.Exit();              // Closes the application
        }


        private void enableFunMode(object sender, EventArgs e)
        {
            funModeActive = true;                      // Activate fun mode
            funModeActivate();                        // Run the fun mode method

        }

        private void disableFunMode(object sender, EventArgs e)
        {
            funModeActive = false;                     // Disable fun mode
            funModeText.Visible = false;                 //  Make "Fun Mode" text not visible
            funModeCountDownText.Visible = false;            //  Make funModeCountDown textbox not visible
        }

        private void funModeActivate()
        {
            funModeText.Visible = true;                 //  Make "Fun Mode" text visible
            funModeCountDownText.Visible = true;            //  Make funModeCountDown textbox visible
            foreach (Control b in Controls)             // For every control in the game, give it a variable b
            {
                if (b is Button && b != resetScore)     // if b is a button except for the button resetScore
                {
                    b.Enabled = true;                   // enable the buttons again
                    b.Text = "";                        // reset the text to blank
                    turnCount = 0;                      // reset turnCount
                    funModeCountDown = 0;               // reset funModeCountDown

                }
                }
            
        }

        private void haveFun()
        {
            if (funModeCountDown == 0)                      // if funModeCountDown is 0
            {
                foreach (Control c in Controls)             // For every control in the game, give it a variable b
                {
                    if (c is Button)                         // if b is a button except for the button resetScore
                    {
                        c.Enabled = true;                   // enable the buttons again
                        turnCount = 0;
                    }
                }
                funModeCountDown = 2;
                funModeCountDownText.Text = funModeCountDown.ToString();    // display funModeCountDown value in "funModeCountDownText" textbox
            }
            else
                funModeCountDown--;
               funModeCountDownText.Text = funModeCountDown.ToString();     // display funModeCountDown value in "funModeCountDownText" textbox
        }

        //Explaining how fun mode works
        private void funModeExplainedButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("When fun mode is activated, the game still starts as a normal game, but a countdown box will start. After the first move is made, for every 3 moves on the board, the buttons will be enabled again and players are able to change other player's previous moves into their own.", "Fun Mode Explained");
        }

    }
}
